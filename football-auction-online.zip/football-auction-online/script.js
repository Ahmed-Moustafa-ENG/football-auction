const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(path.join(__dirname, 'public')));

// مكتبة اللعيبة الموسعة جداً (40 لاعب ومدرب مع صورهم)
const initialPlayersPool = [
    { id: "pel", name: "بيليه", rating: 98, position: "ST", image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80" },
    { id: "mar", name: "دييغو مارادونا", rating: 97, position: "CAM", image: "https://images.unsplash.com/photo-1579952318893-20a310061370?w=150&auto=format&fit=crop&q=80" },
    { id: "zid", name: "زين الدين زيدان", rating: 96, position: "CM", image: "https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=150&auto=format&fit=crop&q=80" },
    { id: "ron_naz", name: "رونالدو الظاهرة", rating: 96, position: "ST", image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=150&auto=format&fit=crop&q=80" },
    { id: "cru", name: "يوهان كرويف", rating: 95, position: "CF", image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=150&auto=format&fit=crop&q=80" },
    { id: "mal", name: "باولو مالديني", rating: 95, position: "CB", image: "https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=150&auto=format&fit=crop&q=80" },
    { id: "ronal", name: "رونالدينيو", rating: 94, position: "LW", image: "https://images.unsplash.com/photo-1543326727-cf6c39e8f84c?w=150&auto=format&fit=crop&q=80" },
    { id: "hen", name: "تييري أونري", rating: 93, position: "ST", image: "https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=150&auto=format&fit=crop&q=80" },
    { id: "mes", name: "ليونيل ميسي", rating: 94, position: "RW", image: "https://images.unsplash.com/photo-1518604666860-9ed391f76460?w=150&auto=format&fit=crop&q=80" },
    { id: "cr7", name: "كريستيانو رونالدو", rating: 93, position: "ST", image: "https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=150&auto=format&fit=crop&q=80" },
    { id: "mbp", name: "كيليان مبابي", rating: 92, position: "ST", image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=150&auto=format&fit=crop&q=80" },
    { id: "haa", name: "إرلينغ هالاند", rating: 91, position: "ST", image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80" },
    { id: "deb", name: "كيفين دي بروين", rating: 91, position: "CM", image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=150&auto=format&fit=crop&q=80" },
    { id: "rod", name: "رودري", rating: 91, position: "CDM", image: "https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=150&auto=format&fit=crop&q=80" },
    { id: "bel", name: "جود بيلينجهام", rating: 90, position: "CAM", image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=150&auto=format&fit=crop&q=80" },
    { id: "vini", name: "فينيسيوس جونيور", rating: 90, position: "LW", image: "https://images.unsplash.com/photo-1543326727-cf6c39e8f84c?w=150&auto=format&fit=crop&q=80" },
    { id: "cou", name: "تيبو كورتوا", rating: 90, position: "GK", image: "https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=150&auto=format&fit=crop&q=80" },
    { id: "kan", name: "هاري كين", rating: 90, position: "ST", image: "https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=150&auto=format&fit=crop&q=80" },
    { id: "sal", name: "محمد صلاح", rating: 89, position: "RW", image: "https://images.unsplash.com/photo-1579952318893-20a310061370?w=150&auto=format&fit=crop&q=80" },
    { id: "vd", name: "فيرجيل فان دايك", rating: 89, position: "CB", image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80" },
    { id: "yam", name: "لامين يامال", rating: 88, position: "RW", image: "https://images.unsplash.com/photo-1518604666860-9ed391f76460?w=150&auto=format&fit=crop&q=80" },
    { id: "sak", name: "بوكايو ساكا", rating: 88, position: "RW", image: "https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=150&auto=format&fit=crop&q=80" },
    { id: "mus", name: "جمال موسيالا", rating: 88, position: "CAM", image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=150&auto=format&fit=crop&q=80" },
    { id: "wirtz", name: "فلوريان فيرتز", rating: 88, position: "CAM", image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=150&auto=format&fit=crop&q=80" },
    { id: "alison", name: "أليسون بيكر", "rating": 89, position: "GK", image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=150&auto=format&fit=crop&q=80" },
    { id: "ant", name: "أنتوني", rating: 78, position: "RW", image: "https://images.unsplash.com/photo-1579952318893-20a310061370?w=150&auto=format&fit=crop&q=80" },
    { id: "mag", name: "هاري ماغواير", rating: 79, position: "CB", image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80" },
    { id: "pep", name: "المدرب: بيب غوارديولا", rating: 94, position: "Manager", image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=150&auto=format&fit=crop&q=80" },
    { id: "anc", name: "المدرب: كارلو أنشيلوتي", rating: 93, position: "Manager", image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=150&auto=format&fit=crop&q=80" }
];

let rooms = {};

function createGameState() {
    return {
        players: {},
        playersList: [],
        pool: JSON.parse(JSON.stringify(initialPlayersPool)),
        currentAuction: null,
        hiddenFreePlayer: null,
        activeTurnIndex: 0,
        timeLeft: 45,
        timer: null,
        status: 'waiting'
    };
}

io.on('connection', (socket) => {
    socket.on('joinRoom', ({ roomId, playerName }) => {
        socket.join(roomId);
        if (!rooms[roomId]) rooms[roomId] = createGameState();
        let room = rooms[roomId];

        if (room.playersList.length >= 2) {
            socket.emit('errorMsg', 'الغرفة ممتلئة!');
            return;
        }

        const playerNum = room.playersList.length + 1;
        room.players[socket.id] = {
            socketId: socket.id,
            name: playerName || `لاعب ${playerNum}`,
            num: playerNum,
            budget: 200,
            team: []
        };
        room.playersList.push(socket.id);

        socket.emit('initPlayer', { num: playerNum, socketId: socket.id });
        io.to(roomId).emit('updateRoomState', getRoomData(room));

        if (room.playersList.length === 2 && room.status === 'waiting') {
            startNewAuction(roomId);
        }
    });

    socket.on('placeBid', ({ roomId, bidAmount }) => {
        let room = rooms[roomId];
        if (!room || room.status !== 'auctioning') return;

        if (socket.id !== room.playersList[room.activeTurnIndex]) {
            socket.emit('errorMsg', 'ليس دورك!');
            return;
        }

        let player = room.players[socket.id];
        bidAmount = parseInt(bidAmount);

        if (isNaN(bidAmount) || bidAmount <= room.currentAuction.currentBid || bidAmount > player.budget) {
            socket.emit('errorMsg', 'مزايدة غير صالحة!');
            return;
        }

        room.currentAuction.currentBid = bidAmount;
        room.currentAuction.highestBidder = socket.id;
        room.currentAuction.highestBidderName = player.name;

        room.activeTurnIndex = (room.activeTurnIndex + 1) % 2;
        io.to(roomId).emit('updateRoomState', getRoomData(room));
    });

    socket.on('passTurn', ({ roomId }) => {
        let room = rooms[roomId];
        if (!room || room.status !== 'auctioning' || socket.id !== room.playersList[room.activeTurnIndex]) return;
        room.activeTurnIndex = (room.activeTurnIndex + 1) % 2;
        io.to(roomId).emit('updateRoomState', getRoomData(room));
    });

    socket.on('foldAuction', ({ roomId }) => {
        let room = rooms[roomId];
        if (!room || room.status !== 'auctioning') return;
        let opponentId = room.playersList.find(id => id !== socket.id);
        room.currentAuction.highestBidder = opponentId;
        finishAuction(roomId, `تنازل ${room.players[socket.id].name}!`);
    });
});

function startNewAuction(roomId) {
    let room = rooms[roomId];
    if (!room) return;

    if (room.pool.length < 2) {
        room.status = 'match';
        io.to(roomId).emit('startMatch', getRoomData(room));
        return;
    }

    room.status = 'auctioning';
    room.currentAuction = {
        player: room.pool.splice(Math.floor(Math.random() * room.pool.length), 1)[0],
        currentBid: 0,
        highestBidder: null,
        highestBidderName: 'لا يوجد'
    };
    room.hiddenFreePlayer = room.pool.splice(Math.floor(Math.random() * room.pool.length), 1)[0];
    room.timeLeft = 45;

    clearInterval(room.timer);
    room.timer = setInterval(() => {
        room.timeLeft--;
        if (room.timeLeft <= 0) {
            clearInterval(room.timer);
            finishAuction(roomId, "انتهى الوقت المحدد للمزاد!");
        } else {
            io.to(roomId).emit('timerUpdate', room.timeLeft);
        }
    }, 1000);

    io.to(roomId).emit('newAuctionStarted', getRoomData(room));
}

function finishAuction(roomId, reason) {
    let room = rooms[roomId];
    if (!room) return;
    clearInterval(room.timer);

    let winnerId = room.currentAuction.highestBidder;
    let loserId = room.playersList.find(id => id !== winnerId);

    if (winnerId && loserId) {
        room.players[winnerId].budget -= room.currentAuction.currentBid;
        room.players[winnerId].team.push(room.currentAuction.player);
        room.players[loserId].team.push(room.hiddenFreePlayer);
    }

    io.to(roomId).emit('auctionFinished', {
        reason: reason,
        freePlayer: room.hiddenFreePlayer,
        roomData: getRoomData(room)
    });

    setTimeout(() => startNewAuction(roomId), 4000);
}

function getRoomData(room) {
    return {
        players: room.players,
        playersList: room.playersList,
        currentAuction: room.currentAuction,
        activeTurnSocketId: room.playersList[room.activeTurnIndex],
        timeLeft: room.timeLeft
    };
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`السيرفر يعمل الآن على المنفذ http://localhost:${PORT}`));